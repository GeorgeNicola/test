var prizeRange = {

    // prod Neptune IDs
    33617: {
        playerType: "NORM0",
        spin1: 2,
        spin2: 3,
        spin3: 5,
        bonus1: 1,
        bonus2: 3,
        bonus3: 5,
        playerStatus: 'NORM'
    },
    33618: {
        playerType: "NORM1",
        spin1: 2,
        spin2: 3,
        spin3: 5,
        bonus1: 1,
        bonus2: 3,
        bonus3: 5,
        playerStatus: 'NORM'
    },
    33619: {
        playerType: "NORM2",
        spin1: 2,
        spin2: 3,
        spin3: 5,
        bonus1: 1,
        bonus2: 3,
        bonus3: 5,
        playerStatus: 'NORM'
    },
    33620: {
        playerType: "NORM3",
        spin1: 2,
        spin2: 3,
        spin3: 5,
        bonus1: 1,
        bonus2: 3,
        bonus3: 5,
        playerStatus: 'NORM'
    },
    33621: {
        playerType: "HV0",
        spin1: 3,
        spin2: 5,
        spin3: 10,
        bonus1: 3,
        bonus2: 5,
        bonus3: 10,
        playerStatus: 'HV'
    },
    33622: {
        playerType: "HV1",
        spin1: 3,
        spin2: 5,
        spin3: 10,
        bonus1: 3,
        bonus2: 5,
        bonus3: 10,
        playerStatus: 'HV'
    },
    33623: {
        playerType: "HV2",
        spin1: 3,
        spin2: 5,
        spin3: 10,
        bonus1: 3,
        bonus2: 5,
        bonus3: 10,
        playerStatus: 'HV'
    },
    33624: {
        playerType: "HV3",
        spin1: 3,
        spin2: 5,
        spin3: 10,
        bonus1: 3,
        bonus2: 5,
        bonus3: 10,
        playerStatus: 'HV'
    },
    33625: {
        playerType: "VIP0",
        spin1: 5,
        spin2: 10,
        spin3: 15,
        bonus1: 5,
        bonus2: 10,
        bonus3: 15,
        playerStatus: 'VIP'
    },
    33626: {
        playerType: "VIP1",
        spin1: 5,
        spin2: 10,
        spin3: 15,
        bonus1: 5,
        bonus2: 10,
        bonus3: 15,
        playerStatus: 'VIP'
    },
    33627: {
        playerType: "VIP2",
        spin1: 5,
        spin2: 10,
        spin3: 15,
        bonus1: 5,
        bonus2: 10,
        bonus3: 15,
        playerStatus: 'VIP'
    },
    33628: {
        playerType: "VIP3",
        spin1: 5,
        spin2: 10,
        spin3: 15,
        bonus1: 5,
        bonus2: 10,
        bonus3: 15,
        playerStatus: 'VIP'
    },

    //test Neptune IDs
    41233: {
        playerType: "NORM0",
        spin1: 2,
        spin2: 3,
        spin3: 5,
        bonus1: 1,
        bonus2: 3,
        bonus3: 5,
        playerStatus: 'NORM'
    },
    41234: {
        playerType: "NORM1",
        spin1: 2,
        spin2: 3,
        spin3: 5,
        bonus1: 1,
        bonus2: 3,
        bonus3: 5,
        playerStatus: 'NORM'
    },
    41235: {
        playerType: "NORM2",
        spin1: 2,
        spin2: 3,
        spin3: 5,
        bonus1: 1,
        bonus2: 3,
        bonus3: 5,
        playerStatus: 'NORM'
    },
    41236: {
        playerType: "NORM3",
        spin1: 2,
        spin2: 3,
        spin3: 5,
        bonus1: 1,
        bonus2: 3,
        bonus3: 5,
        playerStatus: 'NORM'
    },
    41237: {
        playerType: "HV0",
        spin1: 3,
        spin2: 5,
        spin3: 10,
        bonus1: 3,
        bonus2: 5,
        bonus3: 10,
        playerStatus: 'HV'
    },
    41238: {
        playerType: "HV1",
        spin1: 3,
        spin2: 5,
        spin3: 10,
        bonus1: 3,
        bonus2: 5,
        bonus3: 10,
        playerStatus: 'HV'
    },
    41239: {
        playerType: "HV2",
        spin1: 3,
        spin2: 5,
        spin3: 10,
        bonus1: 3,
        bonus2: 5,
        bonus3: 10,
        playerStatus: 'HV'
    },
    41240: {
        playerType: "HV3",
        spin1: 3,
        spin2: 5,
        spin3: 10,
        bonus1: 3,
        bonus2: 5,
        bonus3: 10,
        playerStatus: 'HV'
    },
    41241: {
        playerType: "VIP0",
        spin1: 5,
        spin2: 10,
        spin3: 15,
        bonus1: 5,
        bonus2: 10,
        bonus3: 15,
        playerStatus: 'VIP'
    },
    41242: {
        playerType: "VIP1",
        spin1: 5,
        spin2: 10,
        spin3: 15,
        bonus1: 5,
        bonus2: 10,
        bonus3: 15,
        playerStatus: 'VIP'
    },
    41243: {
        playerType: "VIP2",
        spin1: 5,
        spin2: 10,
        spin3: 15,
        bonus1: 5,
        bonus2: 10,
        bonus3: 15,
        playerStatus: 'VIP'
    },
    41244: {
        playerType: "VIP3",
        spin1: 5,
        spin2: 10,
        spin3: 15,
        bonus1: 5,
        bonus2: 10,
        bonus3: 15,
        playerStatus: 'VIP'
    }
}
var tnc = {
    'NORM': {
        'sig': 'I giocatori eleggibili per la promozione possono vincere un solo premio ogni giorno • La probabilità di conseguire premi varia in base all’attività di gioco e di ricarica di ciascun giocatore • Le Giocate Gratis e le Free Spin hanno validità 14 giorni e sono valide esclusivamente per la selezione dei giochi indicati • Le vincite accumulate utilizzando le Giocate Gratis non potranno superare il valore dell’importo del pacchetto di Giocate Gratis del pacchetto ricevuto e saranno accreditate sotto forma di Bonus Casinò con una durata di 90 giorni e “Requisito di puntata pari a 30” • Le vincite accumulate utilizzando i pacchetti di 2, 3 e 5 Free Spin non potranno superare rispettivamente il valore di 2€, 3€ e 4€ e saranno accreditate sotto forma di Bonus Casinò con una durata di 90 giorni e “Requisito di puntata pari a 30” • La contribuzione al requisito di puntata varia a seconda dei giochi • Si applicano   <a  onclick="" class="button" id="terms-and-conditions">Termini & Condizioni</a>',
        'tnc': '<div class="page-inner"><ol><li>La promozione è valida fino al 28.2.2021.</li><li>La promozione è riservata esclusivamente ai giocatori che hanno ricevuto l’apposito invito e non può essere in alcun modo ceduta a terzi.</li><li>La promozione è riservata esclusivamente ai giocatori che nei 14 giorni precedenti hanno effettuato almeno una ricarica del conto di gioco e hanno accumulato puntate effettuate con Credito di Gioco su 888casino per un importo di almeno 20€.</li><li>I giocatori diventano eleggibili per partecipare a questa promozione non prima di 48 ore dal momento in cui vengono soddisfatti entrambi i requisiti descritti al punto 3.</li><li>Per vincere un premio, i giocatori devono scegliere uno dei 9 forzieri disponibili nel gioco.</li><li>Una volta che il giocatore ha scelto un forziere, il premio corrispondente viene mostrato e accreditato sul conto di gioco del giocatore.</li><li>In caso di malfunzionamenti durante il gioco, il premio assegnato sarà mostrato nel messaggio ricevuto dopo aver completato il gioco.</li><li>La probabilità di conseguire premi varia in base all’attività di gioco e di ricarica di ciascun giocatore.</li></ol><h2>Giocate Gratis</h2><ol><li>I giocatori possono ricevere un Pacchetto di Giocate Gratis di importo compreso tra 1€ e 5€.</li><li>Le Giocate Gratis vengono accreditate immediatamente dopo che il giocatore ha scelto il forziere contenente le Giocate.</li><li>Una volta accreditate, le Giocate Gratis assegnate con questa promozione hanno una validità di 14 giorni.</li><li>Le Giocate Gratis possono essere utilizzate esclusivamente sui seguenti giochi: French Reelvolution, Trail of Treats, Don Spinchote, Greedy Dragon, Book of Legends, Spin or Treat, Mystic Mask e Wild Saloon. I giocatori sono liberi di decidere come ripartire le Giocate Gratis ricevute fra i giochi selezionati.</li><li>Le eventuali vincite ottenute utilizzando le Giocate Gratis vengono accreditate solo dopo che il giocatore ha utilizzato l’intero pacchetto di Giocate Gratis ricevuto.</li><li>Le eventuali vincite ottenute utilizzando le Giocate Gratis non potranno in alcun modo superare il valore del pacchetto ricevuto.</li><li>Le eventuali vincite ottenute utilizzando le Giocate Gratis saranno accreditate sotto forma di Bonus Casinò con durata 90 giorni e "Requisito di puntata pari a 30". La contribuzione al requisito di puntata varia a seconda dei giochi. Consulta la tabella con la <a href="https://www.888casino.it/promozioni/informativa-sui-bonus/">Contribuzione ai Requisiti di Puntata</a>.</li></ol><h2>Free Spin</h2><ol><li>I giocatori possono ricevere un Pacchetto di 2, 3 o 5 Free Spin, con un tetto massimo per le vincite realizzabili utilizzando le Free Spin di 2€, 3€ e 4€ rispettivamente.</li><li>Una volta accreditate, le Free Spin assegnate con questa promozione hanno una validità di 14 giorni.</li><li>Le Free Spin hanno un valore predefinito di puntata pari a 0.20€.</li><li>Le Free Spin possono essere utilizzate esclusivamente sui seguenti giochi: French Reelvolution, Trail of Treats e Don Spinchote. I giocatori sono liberi di decidere su quale gioco utilizzare le Free Spin ricevute.</li><li>Le eventuali vincite ottenute utilizzando le Free Spin vengono accreditate solo dopo che il giocatore ha utilizzato l’intero pacchetto di Free Spin ricevuto.</li><li>Le eventuali vincite ottenute utilizzando le Free Spin saranno accreditate sotto forma di Bonus Casinò con durata 90 giorni e "Requisito di puntata pari a 30". La contribuzione al requisito di puntata varia a seconda dei giochi. Consulta la tabella con la <a href="https://www.888casino.it/promozioni/informativa-sui-bonus/">Contribuzione ai Requisiti di Puntata</a>.</li></ol><h2>Bonus</h2><ol><li>I giocatori possono ricevere un Bonus Casinò di importo compreso tra 1€ e 5€.</li><li>Il Bonus assegnato e accreditato sul conto di gioco non è prelevabile. Sono prelevabili le eventuali vincite ottenute giocando il Bonus ricevuto entro 90 giorni dall’assegnazione del bonus, solo al raggiungimento del "Requisito di puntata pari a 30", vale a dire al raggiungimento di un totale di puntate non inferiore a 30 volte l’importo del bonus ricevuto. La contribuzione al requisito di puntata varia a seconda dei giochi. Consulta l’informativa sui bonus e la tabella con la Contribuzione ai Requisiti di Puntata a <a href="https://www.888casino.it/promozioni/informativa-sui-bonus/">questo link</a>.</li></ol><h2>Generali</h2><ol><li>Ci riserviamo il diritto di revocare la tua eleggibilità a partecipare e/o continuare a partecipare a questa promozione. In questo caso cesserai di essere eleggibile per le successive promozioni.</li><li>Prelievi: per ulteriori informazioni su come prelevare dal tuo conto di gioco consulta la nostra <a href="https://www.888casino.it/come-ricaricare/prelievi/informativa-sui-prelievi/">Informativa sui prelievi</a>. Si applicano Termini &amp; Condizioni generali sui prelievi.</li><li>I Bonus ottenuti utilizzando Giocate Gratis e Free Spin sono validi esclusivamente su 888casino e non possono essere utilizzati su 888sport e 888poker.</li><li>Tutti i bonus e le eventuali vincite generate dall’utilizzo di essi saranno rimosse dal conto di gioco qualora una o più condizioni non siano rispettate pienamente.</li><li>In casi eccezionali, 888casino si riserva il diritto di cancellare la promozione, di modificarla, o di prolungarne/interromperne il periodo di validità, ad esempio (ma non solo) per motivi di sicurezza o in seguito a comportamenti fraudolenti. Fatte salve eccezioni legate ad eventuali comportamenti fraudolenti, tali cancellazioni, modifiche o sospensioni non si applicano ai giocatori che prima della comunicazione della cancellazione, modifica o sospensione abbiano già preso parte alla promozione, effettuando ad esempio (ma non solo) una ricarica in attesa di ricevere un bonus.</li><li>Si applicano a questa promozione i Termini e condizioni contenuti nell’<a href="https://www.888casino.it/promozioni/informativa-sui-bonus/">Informativa sui bonus e sulle giocate gratis di 888casino.it</a>.</li></ol></div>'
    },
    'HV': {
        'sig': 'I giocatori eleggibili per la promozione possono vincere un solo premio ogni giorno • La probabilità di conseguire premi varia in base all’attività di gioco e di ricarica di ciascun giocatore • Le Giocate Gratis e le Free Spin hanno validità 14 giorni e sono valide esclusivamente per la selezione dei giochi di casinò indicati • Le vincite accumulate utilizzando le Giocate Gratis non potranno superare il valore dell’importo di Giocate Gratis del pacchetto ricevuto e saranno accreditate sotto forma di Bonus Casinò con una durata di 90 giorni e “Requisito di puntata pari a 30” • Le vincite accumulate utilizzando i pacchetti di 3, 5 e 10 Free Spin non potranno superare rispettivamente il valore di 2€, 3€ e 5€ e saranno accreditate sotto forma di Bonus Casinò con una durata di 90 giorni e “Requisito di puntata pari a 30” • La contribuzione al requisito di puntata varia a seconda dei giochi • Si applicano  <a  onclick="" class="button" id="terms-and-conditions">Termini & Condizioni</a>',
        'tnc': '<div class="page-inner"><ol><li>La promozione è valida fino al 28.2.2021.</li><li>La promozione è riservata esclusivamente ai giocatori che hanno ricevuto l’apposito invito e non può essere in alcun modo ceduta a terzi.</li><li>La promozione è riservata esclusivamente ai giocatori che nei 14 giorni precedenti hanno effettuato almeno una ricarica del conto di gioco e hanno accumulato puntate effettuate con Credito di Gioco su 888casino per un importo di almeno 20€.</li><li>I giocatori diventano eleggibili per partecipare a questa promozione non prima di 48 ore dal momento in cui vengono soddisfatti entrambi i requisiti descritti al punto 3.</li><li>Per vincere un premio, i giocatori devono scegliere uno dei 9 forzieri disponibili nel gioco.</li><li>Una volta che il giocatore ha scelto un forziere, il premio corrispondente viene mostrato e accreditato sul conto di gioco del giocatore.</li><li>In caso di malfunzionamenti durante il gioco, il premio assegnato sarà mostrato nel messaggio ricevuto dopo aver completato il gioco.</li><li>La probabilità di conseguire premi varia in base all’attività di gioco e di ricarica di ciascun giocatore.</li></ol><h2>Giocate Gratis</h2><ol><li>I giocatori possono ricevere un Pacchetto di Giocate Gratis di importo compreso tra 1€ e 10€.</li><li>Le Giocate Gratis vengono accreditate immediatamente dopo che il giocatore ha scelto il forziere contenente le Giocate.</li><li>Una volta accreditate, le Giocate Gratis assegnate con questa promozione hanno una validità di 14 giorni.</li><li>Le Giocate Gratis possono essere utilizzate esclusivamente sui seguenti giochi: French Reelvolution, Trail of Treats, Don Spinchote, Greedy Dragon, Book of Legends, Spin or Treat, Mystic Mask e Wild Saloon. I giocatori sono liberi di decidere come ripartire le Giocate Gratis ricevute fra i giochi selezionati.</li><li>Le eventuali vincite ottenute utilizzando le Giocate Gratis vengono accreditate solo dopo che il giocatore ha utilizzato l’intero pacchetto di Giocate Gratis ricevuto.</li><li>Le eventuali vincite ottenute utilizzando le Giocate Gratis non potranno in alcun modo superare il valore del pacchetto ricevuto.</li><li>Le eventuali vincite ottenute utilizzando le Giocate Gratis saranno accreditate sotto forma di Bonus Casinò con durata 90 giorni e "Requisito di puntata pari a 30". La contribuzione al requisito di puntata varia a seconda dei giochi. Consulta la tabella con la <a href="https://www.888casino.it/promozioni/informativa-sui-bonus/">Contribuzione ai Requisiti di Puntata</a>.</li></ol><h2>Free Spin</h2><ol><li>I giocatori possono ricevere un Pacchetto di 3, 5 o 10 Free Spin, con un tetto massimo per le vincite realizzabili utilizzando le Free Spin di 2€, 3€ e 5€ rispettivamente.</li><li>Una volta accreditate, le Free Spin assegnate con questa promozione hanno una validità di 14 giorni.</li><li>Le Free Spin hanno un valore predefinito di puntata pari a 0.20€.</li><li>Le Free Spin possono essere utilizzate esclusivamente sui seguenti giochi: French Reelvolution, Trail of Treats e Don Spinchote. I giocatori sono liberi di decidere su quale gioco utilizzare le Free Spin ricevute.</li><li>Le eventuali vincite ottenute utilizzando le Free Spin vengono accreditate solo dopo che il giocatore ha utilizzato l’intero pacchetto di Free Spin ricevuto.</li><li>Le eventuali vincite ottenute utilizzando le Free Spin saranno accreditate sotto forma di Bonus Casinò con durata 90 giorni e "Requisito di puntata pari a 30". La contribuzione al requisito di puntata varia a seconda dei giochi. Consulta la tabella con la <a href="https://www.888casino.it/promozioni/informativa-sui-bonus/">Contribuzione ai Requisiti di Puntata</a>.</li></ol><h2>Bonus</h2><ol><li>I giocatori possono ricevere un Bonus Casinò di importo compreso tra 1€ e 10€.</li><li>Il Bonus assegnato e accreditato sul conto di gioco non è prelevabile. Sono prelevabili le eventuali vincite ottenute giocando il Bonus ricevuto entro 90 giorni dall’assegnazione del bonus, solo al raggiungimento del "Requisito di puntata pari a 30", vale a dire al raggiungimento di un totale di puntate non inferiore a 30 volte l’importo del bonus ricevuto. La contribuzione al requisito di puntata varia a seconda dei giochi. Consulta l’informativa sui bonus e la tabella con la Contribuzione ai Requisiti di Puntata a <a href="https://www.888casino.it/promozioni/informativa-sui-bonus/">questo link</a>.</li></ol><h2>Generali</h2><ol><li>Ci riserviamo il diritto di revocare la tua eleggibilità a partecipare e/o continuare a partecipare a questa promozione. In questo caso cesserai di essere eleggibile per le successive promozioni.</li><li>Prelievi: per ulteriori informazioni su come prelevare dal tuo conto di gioco consulta la nostra <a href="https://www.888casino.it/come-ricaricare/prelievi/informativa-sui-prelievi/">Informativa sui prelievi</a>. Si applicano Termini &amp; Condizioni generali sui prelievi.</li><li>I Bonus ottenuti utilizzando Giocate Gratis e Free Spin sono validi esclusivamente su 888casino e non possono essere utilizzati su 888sport e 888poker.</li><li>Tutti i bonus e le eventuali vincite generate dall’utilizzo di essi saranno rimosse dal conto di gioco qualora una o più condizioni non siano rispettate pienamente.</li><li>In casi eccezionali, 888casino si riserva il diritto di cancellare la promozione, di modificarla, o di prolungarne/interromperne il periodo di validità, ad esempio (ma non solo) per motivi di sicurezza o in seguito a comportamenti fraudolenti. Fatte salve eccezioni legate ad eventuali comportamenti fraudolenti, tali cancellazioni, modifiche o sospensioni non si applicano ai giocatori che prima della comunicazione della cancellazione, modifica o sospensione abbiano già preso parte alla promozione, effettuando ad esempio (ma non solo) una ricarica in attesa di ricevere un bonus.</li><li>Si applicano a questa promozione i Termini e condizioni contenuti nell’<a href="https://www.888casino.it/promozioni/informativa-sui-bonus/">Informativa sui bonus e sulle giocate gratis di 888casino.it</a>.</li></ol></div>'
    },
    'VIP': {
        'sig': 'I giocatori eleggibili per la promozione possono vincere un solo premio ogni giorno • La probabilità di conseguire premi varia in base all’attività di gioco e di ricarica di ciascun giocatore • Le Giocate Gratis e le Free Spin hanno validità 14 giorni e sono valide esclusivamente per la selezione di giochi di casinò indicati • Le vincite accumulate utilizzando le Giocate Gratis non potranno superare il valore dell’importo di Giocate Gratis del pacchetto ricevuto e saranno accreditate sotto forma di Bonus Casinò con una durata di 90 giorni e “Requisito di puntata pari a 20” • Le vincite accumulate utilizzando i pacchetti di 5, 10 e 15 Free Spin non potranno superare rispettivamente il valore di 3€, 5€ e 10€ e saranno accreditate sotto forma di Bonus Casinò con una durata di 90 giorni e “Requisito di puntata pari a 20” • Si applicano <a  onclick="" class="button" id="terms-and-conditions">Termini & Condizioni</a>',
        'tnc': '<div class="page-inner"><ol><li>La promozione è valida fino al 28.2.2021.</li><li>La promozione è riservata esclusivamente ai giocatori che hanno ricevuto l’apposito invito e non può essere in alcun modo ceduta a terzi.</li><li>La promozione è riservata esclusivamente ai giocatori che nei 14 giorni precedenti hanno effettuato almeno una ricarica del conto di gioco e hanno accumulato puntate effettuate con Credito di Gioco su 888casino per un importo di almeno 20€.</li><li>I giocatori diventano eleggibili per partecipare a questa promozione non prima di 48 ore dal momento in cui vengono soddisfatti entrambi i requisiti descritti al punto 3.</li><li>Per vincere un premio, i giocatori devono scegliere uno dei 9 forzieri disponibili nel gioco.</li><li>Una volta che il giocatore ha scelto un forziere, il premio corrispondente viene mostrato e accreditato sul conto di gioco del giocatore.</li><li>In caso di malfunzionamenti durante il gioco, il premio assegnato sarà mostrato nel messaggio ricevuto dopo aver completato il gioco.</li><li>La probabilità di conseguire premi varia in base all’attività di gioco e di ricarica di ciascun giocatore.</li></ol><h2>Giocate Gratis</h2><ol><li>I giocatori possono ricevere un Pacchetto di Giocate Gratis di importo compreso tra 3€ e 15€.</li><li>Le Giocate Gratis vengono accreditate immediatamente dopo che il giocatore ha scelto il forziere contenente le Giocate.</li><li>Una volta accreditate, le Giocate Gratis assegnate con questa promozione hanno una validità di 14 giorni.</li><li>Le Giocate Gratis possono essere utilizzate esclusivamente sui seguenti giochi: French Reelvolution, Trail of Treats, Don Spinchote, Greedy Dragon, Book of Legends, Spin or Treat, Mystic Mask e Wild Saloon. I giocatori sono liberi di decidere come ripartire le Giocate Gratis ricevute fra i giochi selezionati.</li><li>Le eventuali vincite ottenute utilizzando le Giocate Gratis vengono accreditate solo dopo che il giocatore ha utilizzato l’intero pacchetto di Giocate Gratis ricevuto.</li><li>Le eventuali vincite ottenute utilizzando le Giocate Gratis non potranno in alcun modo superare il valore del pacchetto ricevuto.</li><li>Le eventuali vincite ottenute utilizzando le Giocate Gratis saranno accreditate sotto forma di Bonus Casinò con durata 90 giorni e "Requisito di puntata pari a 20". Consulta l’informativa sui bonus a <a href="https://www.888casino.it/promozioni/informativa-sui-bonus/">questo link</a>.</li></ol><h2>Free Spin</h2><ol><li>I giocatori possono ricevere un Pacchetto di 5, 10 o 15 Free Spin, con un tetto massimo per le vincite realizzabili utilizzando le Free Spin di 3€, 5€ e 10€ rispettivamente.</li><li>Una volta accreditate, le Free Spin assegnate con questa promozione hanno una validità di 14 giorni.</li><li>Le Free Spin hanno un valore predefinito di puntata pari a 0.20€.</li><li>Le Free Spin possono essere utilizzate esclusivamente sui seguenti giochi: French Reelvolution, Trail of Treats e Don Spinchote. I giocatori sono liberi di decidere su quale gioco utilizzare le Free Spin ricevute.</li><li>Le eventuali vincite ottenute utilizzando le Free Spin vengono accreditate solo dopo che il giocatore ha utilizzato l’intero pacchetto di Free Spin ricevuto.</li><li>Le eventuali vincite ottenute utilizzando le Free Spin saranno accreditate sotto forma di Bonus Casinò con durata 90 giorni e "Requisito di puntata pari a 20". Consulta l’informativa sui bonus a <a href="https://www.888casino.it/promozioni/informativa-sui-bonus/">questo link</a>.</li></ol><h2>Bonus</h2><ol><li>I giocatori possono ricevere un Bonus Casinò di importo compreso tra 3€ e 15€.</li><li>Il Bonus assegnato e accreditato sul conto di gioco non è prelevabile. Sono prelevabili le eventuali vincite ottenute giocando il Bonus ricevuto entro 90 giorni dall’assegnazione del bonus, solo al raggiungimento del "Requisito di puntata pari a 20", vale a dire al raggiungimento di un totale di puntate non inferiore a 20 volte l’importo del bonus ricevuto. Consulta l’informativa sui bonus a <a href="https://www.888casino.it/promozioni/informativa-sui-bonus/">questo link</a>.</li></ol><h2>Generali</h2><ol><li>Ci riserviamo il diritto di revocare la tua eleggibilità a partecipare e/o continuare a partecipare a questa promozione. In questo caso cesserai di essere eleggibile per le successive promozioni.</li><li>Prelievi: per ulteriori informazioni su come prelevare dal tuo conto di gioco consulta la nostra <a href="https://www.888casino.it/come-ricaricare/prelievi/informativa-sui-prelievi/">Informativa sui prelievi</a>. Si applicano Termini &amp; Condizioni generali sui prelievi.</li><li>I Bonus ottenuti utilizzando Giocate Gratis e Free Spin sono validi esclusivamente su 888casino e non possono essere utilizzati su 888sport e 888poker.</li><li>Tutti i bonus e le eventuali vincite generate dall’utilizzo di essi saranno rimosse dal conto di gioco qualora una o più condizioni non siano rispettate pienamente.</li><li>In casi eccezionali, 888casino si riserva il diritto di cancellare la promozione, di modificarla, o di prolungarne/interromperne il periodo di validità, ad esempio (ma non solo) per motivi di sicurezza o in seguito a comportamenti fraudolenti. Fatte salve eccezioni legate ad eventuali comportamenti fraudolenti, tali cancellazioni, modifiche o sospensioni non si applicano ai giocatori che prima della comunicazione della cancellazione, modifica o sospensione abbiano già preso parte alla promozione, effettuando ad esempio (ma non solo) una ricarica in attesa di ricevere un bonus.</li><li>Si applicano a questa promozione i Termini e condizioni contenuti nell’<a href="https://www.888casino.it/promozioni/informativa-sui-bonus/">Informativa sui bonus e sulle giocate gratis di 888casino.it</a>.</li></ol></div>'
    }
}
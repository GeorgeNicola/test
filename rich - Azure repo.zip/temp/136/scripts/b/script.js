'use strict';

var _translation;

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/*try { */
var version = 'v1.5';
/* This Version is publised */
/* V1.5 - QA #5 */
/* V1.4 - QA #4 */
/* V1.3 - QA #2 */
/* V1.2 - Deal with some errors + QA notes + added CTA */
/* V1.1 - Added Kibana messages for warning and error scenarios */
/* V1.0 - Ready for First QA */
/* V0.1 - First Beta and old game design */

var kibanaMessages = {
    'progress': 'itDailyBonusProgress',
    'warning': 'itDailyBonusWarning',
    'error': 'itDailyBonusError',
    'played': 'itDailyBonusAlreadyPlayed'
};

var pleaseReLoginMessage = "DISCONNETTI<br><br>La sessione è stata interrotta.";

if (typeof dataLayer === 'undefined') {
    var message = 'CAN\'T GET CAMPAIN DATA - dataLayer';
    var messageToDisplay = 'Purtroppo la pagina non si carica correttamente.<br>Stiamo lavorando per risolvere il problema, ti invitiamo a riprovare più tardi.';
    var messageID = '#009';
    errorMessage(message, messageToDisplay, messageID);
    kibana(kibanaMessages.error, '', '', '', '', '', messageID);
}

var testUserCID = 7265809101;
var CID = dataLayer[0].userData.cid;
var valid = CID == testUserCID;
console.log(valid);
/****************/
/* DECLERATIONS */
/****************/

/* Check If Mobile */
var isMobile = _isMobile();

/* Is the enviorment is Rich or local test */
var isLive = _isLive();
checkWhichBrand();
var playedBrand = checkWhichBrand();
var canPlay = true;

// var timerActiv = true;
// if (window.localStorage.getItem('debug')) {
//     timerActiv = false;
// }


var translationCongrats = '<p style="font-weight: 600;">Congratulazioni,</p>hai vinto';
var translation = (_translation = {
    '2 free spin': '2 Free Spin',
    '3 free spin': '3 Free Spin',
    '5 free spin': '5  Free Spin',
    '1 giocate gratis': '1€ in Giocate Gratis',
    '3 giocate gratis': '3€ in Giocate Gratis',
    '5 giocate gratis': '5€ in Giocate Gratis',
    '1 bonus': '1€ di Bonus',
    '3 bonus': '3€ di Bonus',
    '5 bonus': '5€ di Bonus'
}, _defineProperty(_translation, '3 free spin', '3 Free Spin'), _defineProperty(_translation, '5 free spin', '5 Free Spin'), _defineProperty(_translation, '10 free spin', '10 Free Spin'), _defineProperty(_translation, '3 giocate gratis', '3€ in Giocate Gratis'), _defineProperty(_translation, '5 giocate gratis', '5€ in Giocate Gratis'), _defineProperty(_translation, '10 giocate gratis', '10€ in Giocate Gratis'), _defineProperty(_translation, '3 bonus', '3€ di Bonus'), _defineProperty(_translation, '5 bonus', '5€ di Bonus'), _defineProperty(_translation, '10 bonus', '10€ di Bonus'), _defineProperty(_translation, '5 free spin', '5 Free Spin'), _defineProperty(_translation, '10 free spin', '10 Free Spin'), _defineProperty(_translation, '15 free spin', '15 Free Spin'), _defineProperty(_translation, '5 giocate gratis', '5€ in Giocate Gratis'), _defineProperty(_translation, '10 giocate gratis', '10€ in Giocate Gratis'), _defineProperty(_translation, '15 giocate gratis', '15€ in Giocate Gratis'), _defineProperty(_translation, '5 bonus', '5€ di Bonus'), _defineProperty(_translation, '10 bonus', '10€ di Bonus'), _defineProperty(_translation, '15 bonus', '15€ di Bonus'), _translation);
var translationPackage = {
    'free spin': ' Free Spin',
    'Giocate Gratis': '€ in Giocate Gratis',
    'Bonus': '€ di Bonus'
};
var currentDate = new Date();
var dataRich = getDataRich();
var account = dataRich.accountdetails;
var session = dataRich.applicationcontext;
if (dataRich.marketingcampaigndata.marketingcampaigns == null) {
    var message = 'Player have to re-login first';
    var messageToDisplay = pleaseReLoginMessage + '<br><br>';
    var messageID = '#011';
    errorMessage(message, messageToDisplay, messageID);
    kibana(kibanaMessages.error, '', '', CID, '', '', messageID);
}
var campaigns = dataRich.marketingcampaigndata.marketingcampaigns[0];

var claimPrize = null;
var claimGuid = null;
var promotionID = null;
var claimName;
var claimRuleID;
var otherPrizes = null;
if (valid) credits();

if (valid) console.log(p('> Declarations'), c('#ffffff', '#999999'));

// if (valid) console.log(p('> CID:\t\t\t\t\t\t' + CID), c('#999999'));

var richCampaignID = campaigns.marketingcampaignid;
if (valid) console.log(p('> richCampaignID:\t\t\t' + richCampaignID), c('#999999'));
var richImagePath = '/Campaigns/' + richCampaignID + '/images/';

var brandID = account.brandid;
if (valid) console.log(p('> brandID:\t\t\t\t\t' + brandID), c('#999999'));
var currency = account.currency;
if (valid) console.log(p('> currency:\t\t\t\t\t' + currency), c('#999999'));
var firstName = account.firstname;
// if (valid) console.log(p('> firstName:\t\t\t\t' + firstName), c('#999999'));

var language = session.language;
// if (valid) console.log(p('> language:\t\t\t\t\t' + language), c('#999999'));

/*var currentCampaign = campaigns.campaigns[0].scheduledrules[0];*/
var campaignList = campaigns.campaigns;
var errorMessageError = 'CLAIM EXPIRED';
var errorMessageToDisplay = 'Ci dispiace, la promozione “Un tesoro ogni giorno” è terminata.';
var errorMessageID = '#002';
var serverTime = new Date(session.serverdatetime);
var serverMonth = serverTime.getMonth() < 10 ? '0' + eval(serverTime.getMonth() + 1) : eval(serverTime.getMonth() + 1);
var serverDay = serverTime.getDay() < 10 ? '0' + serverTime.getDay() : serverTime.getDay();
var serverDate = serverTime.getFullYear() + '-' + serverMonth + '-' + serverDay;
var availableArrays = [];
$.each(campaignList, function (indexA, thisCampaign) {
    $.each(thisCampaign.scheduledrules, function (indexB, thisRule) {
        var endDate = thisRule.enddate;
        var startDate = thisRule.startdate;

        var newEnd = new Date(endDate);
        var newStart = new Date(startDate);
        // check if we have valid campaign server time is between start and end time of campaign

        // if (serverTime.getTime() <= newEnd.getTime() && serverTime.getTime() >= newStart.getTime()) {
        //     availableArrays.push(thisRule);
        // }
        if (endDate.indexOf(serverDate) > -1) {
            availableArrays.push(thisRule);
        }
        if (serverTime.getTime() < newEnd.getTime()) {
            var currentCampaignStatus = thisRule.status;
            if (currentCampaignStatus == 4 || currentCampaignStatus == 1) {
                console.log('campaign with valid status:');
                console.log(thisRule);
                var startDate = thisRule.startdate;
                var ruleID = thisRule.ruleid;

                /* Get Only Active Campaign */
                var thisRuleCompletions = thisRule.rulecompletions;
                if (thisRuleCompletions != null) {
                    $.each(thisRuleCompletions, function (indexC, thisRuleItem) {

                        var ActiveCampaign = thisRuleItem.completionactions[0];

                        /* Get Only The Randome Prize That Player Can Get */
                        var activePrize = ActiveCampaign.offers;
                        $.each(activePrize, function (indexD, value) {
                            if (claimPrize == null) {
                                if (value.claimbonusstatus != null) {
                                    if (value.claimbonusstatus == 5) {
                                        claimPrize = {
                                            'status': activePrize[indexD].claimbonusstatus,
                                            'guid': activePrize[indexD].claimidentifier,
                                            'bonus': activePrize[indexD].bonusofferdata,
                                            'name': getPrizeName(activePrize[indexD])
                                        };
                                        claimGuid = claimPrize.guid;
                                        claimName = claimPrize.name;
                                        claimRuleID = ruleID;
                                        promotionID = ActiveCampaign.promotionid;

                                        if (valid) console.log(p('> promotionid:\t\t\t\t' + ActiveCampaign.promotionid), c('#999999'));
                                        if (valid) console.log(p('> claimPrize.status:\t\t\t' + claimPrize.status), c('#999999'));
                                        if (valid) console.log(p('> claimPrize.guid:\t\t\t' + claimPrize.guid), c('#999999'));
                                        if (valid) console.log(p('> claimPrize.name:\t\t\t' + claimPrize.name), c('#999999'));
                                        if (valid) console.log(' ');
                                        $('.left-area').removeAttr('style');
                                        $('#chests').removeAttr('style');
                                    }
                                }
                            }
                        });
                    });
                }
            }
            campaignList = campaigns.campaigns;
            errorMessageError = 'PLAYER ALREADY PLAYED';
            errorMessageToDisplay = 'Purtroppo il tesoro è scaduto, torna domani per aprire un nuovo forziere.';

            errorMessageID = '#010';
        }
    });
});
if (!availableArrays.length) {
    console.log(p('no Campaign'), c('black', 'red'));
} else {
    console.log('Available campaigns for today:');
    console.log(availableArrays);
}
if (promotionID == null) {
    var dataRichString = JSON.stringify(dataRich);
    var startloc = dataRichString.indexOf('promotionid') + 14;
    promotionID = dataRichString.substring(startloc, startloc + 5);
    if (valid) console.log(p('> promotionid:\t\t\t\t' + promotionID), c('#999999'));
}

if (claimGuid == null) {

    console.log(p('> ' + errorMessageError), c('red', 'black'));
    console.log(' ');
    errorMessage(errorMessageError, errorMessageToDisplay, errorMessageID);
    kibana(kibanaMessages.played, brandID, '', CID, '', '', errorMessageID);
} else {
    /* Get The Prize Only */
    //if(otherPrizes == null) {
    if (valid) console.log(' ');
    if (valid) console.log(p('> otherPrizes:'), c('#999999'));
    otherPrizes = campaignList[0].scheduledrules[0].ruleactions[0].offers;
    otherPrizes = shuffleArray(otherPrizes);
    for (var indexE = 0; indexE < otherPrizes.length; indexE++) {
        otherPrizes[indexE].packagenamePrize = getPrizeName(otherPrizes[indexE]);
        if (otherPrizes[indexE].packagenamePrize == claimName) {
            otherPrizes.splice(indexE, 1);
            indexE--;
        } else {}
    }
    //}
}

/**************/
/* INITILAIZE */
/**************/

fillprizeRange();
var selectedChest = null;
var showOtherPrizes = false;
var scrolls;
var closePage = $('.close-page');
var chests = $('#chests');
var chestImages = {
    'close': (isLive ? richImagePath : 'images/') + 'closed-chest.png',
    'open': (isLive ? richImagePath : 'images/') + 'opened-chest.png'
};
var scrollImages = {
    'selected': (isLive ? richImagePath : 'images/') + 'Popup_Message.png',
    'other': (isLive ? richImagePath : 'images/') + 'Not_Poped_Message.png'
};

/*********/
/* READY */
/*********/

$(document).ready(function () {
    if (!canPlay) {
        var message = 'RICH ERROR - YOU CAN\'T PLAY';
        var messageToDisplay = 'Purtroppo la pagina non si carica correttamente.<br>Stiamo lavorando per risolvere il problema, ti invitiamo a riprovare più tardi.';
        var messageID = '#008';
        errorMessage(message, messageToDisplay, messageID);
        kibana(kibanaMessages.error, brandID, claimRuleID, CID, claimName, '', messageID);
    }
    if (window.innerHeight < $('#canvas').height()) {
        $('#generalIframe', window.parent.document).height(eval(window.innerHeight - 20) + 'px');
    }
});

/**********/
/* EVENTS */
/**********/

/* When Player Click On Chest */
chests.one('click', 'li', function () {
    clickedOnChest($(this));
});

/* Open Page */
$('.button').on('click', function () {
    $('#' + $(this).attr('id') + '-page').fadeIn();
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
});

/* Close Page */
$('.page').on('click', function (e) {
    if (e.target !== this) return;
    $(this).fadeOut();
});
closePage.on('click', function () {
    $(this).parent().fadeOut();
});

/* When User Resize Window */
$(window).on('resize', function (e) {
    console.log(p('> Window Was Resized - ' + $(window).width() + 'x' + $(window).height()), c('#f8f8f8', '#999999'));
    isMobile = _isMobile();
    var canvas = document.getElementById('canvas');
    canvas.width = $('body').width();
    canvas.height = $('body').height();
});

/*************/
/* FUNCTIONS */
/*************/

/* Check If Device Is Mobile Or Not */
function _isMobile() {
    if (/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|ipad|iris|kindle|Android|Silk|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i.test(navigator.userAgent) || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(navigator.userAgent.substr(0, 4))) {
        if (isMobile != true) {
            console.log(p('> Mobile Device Detected'), c('#ffffff', '#000000'));
            $('body').addClass('mobile');
            $('body').removeClass('pc');
        }
        return true;
    } else {
        if (isMobile != false) {
            console.log(p('> Desktop Device Detected'), c('#ffffff', '#000000'));
            $('body').removeClass('mobile');
            $('body').addClass('pc');
        }
        return false;
    }
}

/* Shuffle Arrays */
function shuffleArray(a) {
    for (var i = a.length - 1; i > 0; i--) {
        var j = Math.floor(Math.random() * (i + 1));
        var _ref = [a[j], a[i]];
        a[i] = _ref[0];
        a[j] = _ref[1];
    }
    return a;
}

/* Close The Rich Window */
// function closeRICH() {
//     pf.web.rich.cta.initiatecta({ ActionId: 'CloseMe' });
// }

/* check the brand */
function checkWhichBrand() {
    var brand = null;
    var subdomain = pf.web.rich.data.userdata.accountdetails.subbrandid;
    switch (subdomain) {
        case 116:
            brand = 'sport';
            break;
        case 46:
            brand = 'casino';
            break;
        case 46:
            brand = 'poker';
            break;
        default:
            brand = 'casino';
    }
    $('html').addClass(brand);
    console.log('> Brand: ' + brand);
    return brand;
}

/* Is the enviorment is Rich or local test */
function _isLive() {
    var isLive = window.location.protocol == 'file:' ? false : true;
    if (isLive) {
        console.log(p('> Live Environment'), c('#ffffff', '#000000'));
        $('body').addClass('live');
    } else {
        console.log(p('> Stage Environment'), c('#ffffff', '#000000'));
        $('body').addClass('stage');
    }
    console.log(' ');
    return isLive;
}

/* Color Massages */
function p(string) {
    return '%c' + string;
}

function c() {
    var color = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'white';
    var backgroundColor = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'transperent';

    return 'color: ' + color + '; background-color: ' + backgroundColor + '; padding: 2px 6px; border-radius: 2px;';
}

/* Get DataRich Data */
function getDataRich() {
    console.log(p('> getDataRich'), c('#ffffff', '#a19c00'));
    console.log(p('Sent this information'), c('#a19c00'));

    var dataRich = pf.web.rich.data.userdata;
    if (dataRich != undefined) {
        if (isLive) {
            console.log(p('DataRich Added'), c('#999999'));
        } else {
            console.log(p('STAGE -> Getting Local Test Data'), c('#999999'));
        }
        // if (valid) console.log(dataRich);
        if (valid) console.log(' ');
        return dataRich;
    }
    if (dataRich == undefined || dataRich == null) {
        console.log(p('STAGE -> Getting Local Test Data'), c('#999999'));
    }
}

/* Kibana - Analytics */
function kibana(event, brandID, tier, CID, prizeName, chestNumber) {
    var errorID = arguments.length > 6 && arguments[6] !== undefined ? arguments[6] : '';

    // console.log(p('> kibana', '#ffffff'), c('#ffffff', 'green'));
    // console.log(p('Sent this information'), c('green'));
    // console.log(p('Event: ' + event), c('#999999'));
    // console.log(p('brandID: ' + brandID), c('#999999'));
    // console.log(p('Tier: ' + tier), c('#999999'));
    // console.log(p('CID: ' + CID), c('#999999'));
    // console.log(p('prizeName: ' + prizeName), c('#999999'));
    // console.log(p('chestNumber: ' + chestNumber), c('#999999'));
    // console.log(p('errorID: ' + errorID), c('#999999'));
    // console.log(' ');

    if (isLive) {
        if (event == kibanaMessages.progress) {
            pf.web.rich.tracking.trackevent(event, {
                'brandID': brandID,
                'tier': tier,
                'cid': CID,
                'prizeName': prizeName,
                'chestNumber': chestNumber,
                'errorID': errorID
            });
        } else if (event == kibanaMessages.played) {
            pf.web.rich.tracking.trackevent(event, {
                'brandID': brandID,
                'cid': CID,
                'errorID': errorID
            });
        } else {
            pf.web.rich.tracking.trackevent(event, {
                'errorID': errorID
            });
        }
    }
}

/* Claim */
function claim(guid) {
    console.log(p('> claim', '#ffffff'), c('#ffffff', 'purple'));
    console.log(p('Sent this information'), c('purple'));
    // console.log(p('guid: ' + guid), c('#999999'));

    if (isLive) {

        pf.web.rich.actions.claimbonus(guid, function (status) {
            var success = false;
            var message;
            var messageID;
            var messageToDisplay;
            switch (status) {
                case 1:
                    {
                        message = 'CLAIM SUCCESS';
                        messageToDisplay = 'Congratulazioni!<br><br>Il tesoro è sul tuo conto di gioco, divertiti su 888' + brand + '!';
                        messageID = '#001';
                        success = true;
                        pf.web.rich.cta.initiatecta({
                            ActionId: '64'
                        });
                    }
                    break;
                case 2:
                    {
                        message = 'CLAIM EXPIRED';
                        messageToDisplay = 'Purtroppo il tesoro è scaduto, torna domani per aprire un nuovo forziere.';
                        messageID = '#002';
                    }
                    break;
                case 3:
                    {
                        message = 'PRIZE ALREADY CLAIMED';
                        messageToDisplay = 'Hai già aperto un forziere oggi, torna domani per un nuovo tesoro da scoprire.';
                        messageID = '#003';
                    }
                    break;
                case 4:
                    {
                        message = 'PRIZE CANCELLED';
                        messageToDisplay = 'Purtroppo la pagina non si carica correttamente. Stiamo lavorando per risolvere il problema, ti invitiamo a riprovare più tardi.';
                        messageID = '#004';
                    }
                    break;
                case 5:
                default:
                    {
                        message = 'CLAIM FAILED';
                        messageToDisplay = 'Purtroppo la pagina non si carica correttamente.<br>Stiamo lavorando per risolvere il problema, ti invitiamo a riprovare più tardi.<br><br>';
                        messageID = '#005';
                    }
            }
            if (!success) {
                errorMessage(message, messageToDisplay, messageID);
                kibana(kibanaMessages.progress, brandID, claimRuleID, CID, claimName, selectedChest.id, messageID);
            }
            console.log(' ');
            return status;
        }, function () {
            var message = 'CLAIM GENERAL ERROR';
            var messageToDisplay = 'Purtroppo non puoi aprire il forziere, ma ci saranno presto nuove promozioni.<br><br>Consulta le nostre offerte attive.';
            var messageID = '#006';
            errorMessage(message, messageToDisplay, messageID);
            kibana(kibanaMessages.progress, brandID, claimRuleID, CID, claimName, selectedChest.id, messageID);
        });
    } else {
        console.log(p('STAGE -> No Action Made'), c('#999999'));
        console.log(' ');
    }
}

/* When Chest Is Opened */
function clickedOnChest(chest) {

    selectedChest = {
        'id': chest.index() + 1,
        'object': chest
    };
    chest.closest('li').addClass('selected');
    chests.toggleClass('clicked not-clicked');

    claim(claimGuid);

    /*chest.closest('li').append(scroll);*/
    scrolls = {
        'selected': chests.find('.selected .scroll'),
        'other': chests.find('li:not(.selected) .scroll')
    };
    showOtherPrizes = true;
    startSmoke();
    scrolls.selected.find('.prize').text(claimName);
    scrolls.selected.find('.textEffect').prepend('<p class="" style="padding-bottom: 4%; ">' + translationCongrats + '</p>');
    scrolls.selected.find('img').attr('src', scrollImages.selected);
    setTimeout(function () {
        scrolls.selected.slideDown(800);
        setTimeout(function () {
            /*chest.find('.chest-image').attr('src', chestImages.open);*/
            scrolls.selected.find('p').fadeIn();
            chest.find('.chest-image').fadeOut();
            setTimeout(function () {
                scrolls.other.each(function (index) {
                    $(this).find('.prize').text(otherPrizes[index].packagenamePrize);
                });
                $('.chest img').fadeOut(3000);
                scrolls.other.fadeIn(3000);
                scrolls.other.find('.prize').fadeIn(3000);
                kibana(kibanaMessages.progress, brandID, claimRuleID, CID, claimName, selectedChest.id);
                setTimeout(function () {
                    $('#cta-wrap h2').addClass('hide');
                    $('#cta').fadeIn();
                }, 1400);
            }, 500);
        }, 400);
    }, 200);
}

/* Deal With Error Messages */
function errorMessage(message, messageToDisplay, ID) {
    $('#rich').addClass('errorBody');
    var closeError = $('<div/>', {
        id: "closeErrorEvent",
        class: "errorClose"
    });
    closeError.click(function () {
        closeRICH(playedBrand);
    });

    //messageToDisplay = 'Technical Error';
    var innerDiv = $('<div/>', {
        class: 'error-message-inner'
    }).append('<p class="id"> </p>').prepend('<p>' + messageToDisplay + '</p>');
    var newDiv = $('<div/>', {
        id: 'error-message',
        style: 'height: ' + eval($('#rich').height() - $('#sigTerms').height()) + 'px'
    }).append(innerDiv).hide();
    $('.right-area .wrapper').fadeOut(function () {
        $('.right-area').empty().append(newDiv).prepend(closeError);
        newDiv.fadeIn();
        $('#cta-wrap h2').addClass('hide');
        $('#cta').fadeIn();
    });
    $('.left-area').hide();
}

/* Fill the t&c table */
function fillTheTermsAndConditionsTable() {
    var tarmsTable = $('#termsTable');
    for (var i = 0; i < prizesAndProbabilities.length; i++) {
        if (prizesAndProbabilities[i].promotion == promotionID) {
            var newDiv = tarmsTable.append($('<tr><td><p>' + prizesAndProbabilities[i].prize + '</p></td><td><p>' + prizesAndProbabilities[i].probability + '</p></td></tr>'));
        }
    }
}

function fillprizeRange() {
    var marketingid = promotionID;
    console.log(promotionID);
    if (typeof prizeRange[marketingid] === 'undefined' || prizeRange[marketingid] === null) {
        console.log(p('!!!!! ID Neptune not recegnized - Loaded T&C and Sig Term for NORM !!!!!!'), c('black', 'red'));
        var playerType = 'NORM';
    } else {
        var playerType = prizeRange[marketingid].playerStatus;
    }

    $('#sigTerms').html(tnc[playerType].sig);
    $('#tncPage').html(tnc[playerType].tnc);
}
/* Fill the t&c table */
function translatePrize(packagename) {
    return translation[packagename] || packagename;
}

function getPrizeName(packagename) {
    var packagePrize = '';
    if (packagename.packagename === "free spin") {
        packagePrize = packagename.bonusofferdata.numberofspins + translationPackage[packagename.packagename];
    } else {
        packagePrize = packagename.bonusofferdata.amount / 100 + translationPackage[packagename.packagename];
    }

    return packagePrize;
}
/***********/
/* CREDITS */
/***********/

function credits() {
    // var Brand = checkWhichBrand();
    console.log('');
    console.log(p('@@ This code was written updated by Ionut Mocanu @@'), c('#ffffff', 'red'));
    console.log(p('@@ Rich 2020 - 888.it Daily Game Rich - ' + checkWhichBrand() + ' @@'), c('#ffffff', '#d70000'));
    console.log(' ');
}

/****************/
/* SMOKE EFFECT */
/****************/

var smokemachine = function smokemachine(context, color) {
    color = color || [24, 46.8, 48.2];
    var polyfillAnimFrame = window.requestAnimationFrame || window.mozRequestAnimationFrame || window.webkitRequestAnimationFrame || window.msRequestAnimationFrame;
    var lastframe;
    var currentparticles = [];
    var pendingparticles = [];

    var buffer = document.createElement('canvas'),
        bctx = buffer.getContext('2d');

    buffer.width = 20;
    buffer.height = 20;

    var opacities = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 5, 5, 7, 4, 4, 1, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 17, 27, 41, 52, 56, 34, 23, 15, 11, 4, 9, 5, 1, 0, 0, 0, 0, 0, 0, 1, 45, 63, 57, 45, 78, 66, 52, 41, 34, 37, 23, 20, 0, 1, 0, 0, 0, 0, 1, 43, 62, 66, 64, 67, 115, 112, 114, 56, 58, 47, 33, 18, 12, 10, 0, 0, 0, 0, 39, 50, 63, 76, 87, 107, 105, 112, 128, 104, 69, 64, 29, 18, 21, 15, 0, 0, 0, 7, 42, 52, 85, 91, 103, 126, 153, 128, 124, 82, 57, 52, 52, 24, 1, 0, 0, 0, 2, 17, 41, 67, 84, 100, 122, 136, 159, 127, 78, 69, 60, 50, 47, 25, 7, 1, 0, 0, 0, 34, 33, 66, 82, 113, 138, 149, 168, 175, 82, 142, 133, 70, 62, 41, 25, 6, 0, 0, 0, 18, 39, 55, 113, 111, 137, 141, 139, 141, 128, 102, 130, 90, 96, 65, 37, 0, 0, 0, 2, 15, 27, 71, 104, 129, 129, 158, 140, 154, 146, 150, 131, 92, 100, 67, 26, 3, 0, 0, 0, 0, 46, 73, 104, 124, 145, 135, 122, 107, 120, 122, 101, 98, 96, 35, 38, 7, 2, 0, 0, 0, 50, 58, 91, 124, 127, 139, 118, 121, 177, 156, 88, 90, 88, 28, 43, 3, 0, 0, 0, 0, 30, 62, 68, 91, 83, 117, 89, 139, 139, 99, 105, 77, 32, 1, 1, 0, 0, 0, 0, 0, 16, 21, 8, 45, 101, 125, 118, 87, 110, 86, 64, 39, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 28, 79, 79, 117, 122, 88, 84, 54, 46, 11, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 6, 55, 61, 68, 71, 30, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 14, 23, 25, 20, 12, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 12, 9, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0];

    var data = bctx.createImageData(20, 20);
    var d = data.data;

    for (var i = 0; i < d.length; i += 4) {
        /*d[i]=color[0]
        d[i+1]=color[1]
        d[i+2]=color[2]*/
        d[i] = color[0] + Math.floor(Math.random() * -90);
        d[i + 1] = color[1] + Math.floor(Math.random() * -90);
        d[i + 2] = color[2] + Math.floor(Math.random() * -90);
        d[i + 3] = opacities[i / 4];
    }

    bctx.putImageData(data, 0, 0);

    var imagewidth = 20 * 5;
    var imageheight = 20 * 5;

    function particle(x, y, l) {
        this.x = x;
        this.y = y;
        this.age = 0;
        this.vx = (Math.random() * 8 - 4) / 100;
        this.startvy = -(Math.random() * 30 + 10) / 100;
        this.vy = this.startvy;
        this.scale = Math.random() * .5;
        this.lifetime = Math.random() * l + l / 2;
        this.finalscale = 5 + this.scale + Math.random();

        this.update = function (deltatime) {
            this.x += this.vx * deltatime;
            this.y += this.vy * deltatime;
            var frac = Math.pow(this.age / this.lifetime, .92);
            this.vy = (1 - frac) * this.startvy;
            this.age += deltatime;
            this.scale = frac * this.finalscale;
        };

        this.draw = function () {
            context.globalAlpha = (1 - Math.abs(1 - 2 * this.age / this.lifetime)) / 8;
            var off = this.scale * imagewidth / 2;
            var xmin = this.x - off;
            var xmax = xmin + this.scale * imageheight;
            var ymin = this.y - off;
            var ymax = ymin + this.scale * imageheight;
            context.drawImage(buffer, xmin, ymin, xmax - xmin, ymax - ymin);
        };
    }

    function addparticles(x, y, n, lifetime) {
        lifetime = lifetime || 4000;
        n = n || 10;
        if (n < 1) return Math.random() <= n && pendingparticles.push(new particle(x, y, lifetime));
        for (var i = 0; i < n; i++) {
            pendingparticles.push(new particle(x, y, lifetime));
        };
    }

    function updateanddrawparticles(deltatime) {
        context.clearRect(0, 0, canvas.width, canvas.height);
        deltatime = deltatime || 16;
        var newparticles = [];
        currentparticles = currentparticles.concat(pendingparticles);
        pendingparticles = [];

        currentparticles.forEach(function (p) {
            p.update(deltatime);
            if (p.age < p.lifetime) {
                p.draw();
                newparticles.push(p);
            }
        });
        currentparticles = newparticles;
    }

    function frame(time) {
        if (running) {
            var deltat = time - lastframe;
            lastframe = time;

            updateanddrawparticles(deltat);

            polyfillAnimFrame(frame);
        }
    }

    var running = false;

    function start() {
        running = true;
        polyfillAnimFrame(function (time) {
            lastframe = time;
            polyfillAnimFrame(frame);
        });
    }

    function stop() {
        running = false;
    }

    return {
        start: start,
        stop: stop,
        step: updateanddrawparticles,
        addsmoke: addparticles
    };
};

var canvas = document.getElementById('canvas');
var ctx = canvas.getContext('2d');
canvas.width = $('body').width();
canvas.height = $('body').height();
var party = smokemachine(ctx, [255, 255, 255]);

/*onmousemove = function (e) {
    var x = e.clientX
    var y = e.clientY
    var n = 0
    var t = Math.floor(Math.random() * 200) + 3800
    party.addsmoke(x, y, n, t)
}*/

//startSmoke();
function startSmoke() {
    if (showOtherPrizes) {
        showOtherPrizes = false;

        var addWidth = selectedChest.object.width() / 2;
        var addheight = selectedChest.object.height() / 2;

        party.start();

        var chestX = selectedChest.object.position().left + addWidth;
        var chestY = selectedChest.object.position().top + addheight + 85;

        party.addsmoke(chestX, chestY, 80, Math.floor(Math.random() * 200) + 900);
    }
}

function closeRICH(brand) {
    if (isLive) {
        // if(brand){
        //     openInternal('https://www.888'+brand+'.it')
        // }else{
        //     // pf.web.rich.cta.initiatecta({ ActionId: '27', Url: 'https://www.888casino.it' });

        //     // pf.web.rich.cta.initiatecta({ ActionId: '22' });
        //     openInternal('https://www.888casino.it')

        // }
        // pf.web.rich.cta.initiatecta({ ActionId: '22' });
        console.log('Game Closed!');
        openInternal('https://www.888casino.it');
    } else {
        alert('Closed!');
    }
}

function openInternal(getUrl) {
    if (brandID == 0) {
        var url = getUrl.indexOf('http') === 0 ? getUrl : '/' + getUrl; //add external link to sCasino
        pf.web.rich.cta.initiatecta({
            ActionId: '27',
            Url: url
        });
    } else {
        /*pf.web.rich.cta.initiatecta({ ActionId: '22'}); */
        pf.web.rich.cta.initiatecta({
            ActionId: '27',
            Url: getUrl
        });
    }
}

$('.calm-btn').on('click', function (e) {
    e.preventDefault();
    closeRICH(playedBrand);
});

// stop game after 30sec inactivity
// $(document).ready(function () {
//     var timerClose = 30;
//     $('#terms-and-conditions').click(function () {
//         window.clearInterval(gameInterval);
//     });
//     // $('body').on('click keydown touch touch touchstart touchmove touchend keyup', function (e) { timerClose = 10000; });
//     // if (isLive && timerActiv) {
//     var gameInterval = window.setInterval(stopGameInterval, 1000);
//     // }
//     function stopGameInterval() {
//         console.log(timerClose);

//         if (timerClose <= 0) {

//             closeRICH(playedBrand);
//             window.clearInterval(gameInterval);
//         };
//         timerClose--
//     }

//     $('.close-page').click(function () {
//         if (isLive && timerActiv) {
//             timerClose = 35;
//             gameInterval = window.setInterval(stopGameInterval, 1000);
//         }
//     });
//     $("#closeErrorEvent").on('click', function () { closeRICH(playedBrand); });

// });

// function stop() {
//     var interval_id = window.setInterval("", 9999); // Get a reference to the last
//     // interval +1
//     for (var i = 1; i < interval_id; i++)
//         window.clearInterval(i);
//     //for clearing all intervals
// }
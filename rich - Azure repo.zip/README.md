# Set up your work environment:
1. Make sure you have Node.js v 6.10.0 or above installed
2. Duplicate all the files from the main-scratch-files folder to a new folder
3. Open the command line. Navigate to the root folder
4. OPTIONAL Set up npm proxy by running the following from the command line (replace username (yours) and password) OPTIONAL
    For the first time you build RICH Game: 
    * npm config set proxy http://username:password@10.20.5.226:8080 
    * npm config set https-proxy http://username:password@10.20.5.226:8080

    ### For each RICH: 
    5. Run npm install from the command line
    6. Run npm install grunt –g (mandatory only for the first time) 
    7. Run npm install gulp -g (mandatory only for the first time) 

    For more info on [CONFLUENCE](https://confluence/display/RICH/Dev+Build+Tool+-+User+Manual)


# Create new RICH:
1. Change the campaign number (folder name) inside "*src/Campaigns*" to the correct campaign number (CM will provide)
2. Open the *.version.config* file and make sure it’s on "0" 

# Deploy the RICH
1. STAGE (local env) Run builddev with the campaign ID from the command line ex( ``./builddev 136`` )
    It should create for you a new folder *distdev*, This is the scratch for local.
2. Run buildrel with the campaign ID from the command line ( ``./buildrel 136`` )


    **New RICH  is done!!** 


3. Last phase - upload to [Nolio](http://nolio.888holdings.corp:8080/datamanagement/index.jsp#/main/templates/154) for access try with your email and windows password or open a ticket    
4. Please follow instructions in “Deploy Rich-Campaigns user manual” Doc. 




